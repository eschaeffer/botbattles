﻿function tick(api) {
  // intentionally minimal
}