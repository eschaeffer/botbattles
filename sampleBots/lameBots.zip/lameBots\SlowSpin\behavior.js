﻿function tick(api) {
  api.turn(2);
  api.fire();
}