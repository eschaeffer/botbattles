﻿function tick(api) {
  api.turn(1);
  api.advance(0.1);
}