﻿function tick(api) {
  api.advance(0.4);
}