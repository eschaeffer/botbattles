﻿function tick(api) {
  api.turn(4);
  api.advance(0.3);
}